set -m

    /entrypoint.sh couchbase-server &

   echo "LINE1"
# Couchbase DB Server Ports
# sudo iptables -A INPUT -p tcp -m state –state NEW -m tcp –dport 4369 -j ACCEPT
# sudo iptables -A INPUT -p tcp -m state –state NEW -m tcp –dport 8091 -j ACCEPT
# sudo iptables -A INPUT -p tcp -m state –state NEW -m tcp –dport 80 -j ACCEPT


echo "LINE1.1"
  
    # Setup initial cluster/ Initialize Node
    couchbase-cli cluster-init -c  http://scrapper_v2_couch_db_1 --cluster-name  "currency_stor" --cluster-username "sashasierova" \
    --cluster-password "4esZXdr5" --services data,index,query --cluster-ramsize 256 --cluster-index-ramsize 256 \
    --index-storage-setting default 

    # Setup Administrator username and password
    curl -4 -v http://scrapper_v2_couch_db_1/settings/web -d port=8091 -d username="sashasierova" -d password="4esZXdr5"


    sleep 15

    # Setup Bucket
     couchbase-cli bucket-create -chttp://scrapper_v2_couch_db_1:8091 --username "sashasierova" \
    --password "4esZXdr5" --bucket "currency_rate" --bucket-type couchbase \
    --bucket-ramsize 256

     sleep 15

 

    couchbase-cli setting-index -c http://scrapper_v2_couch_db_1:8091 --username "sashasierova" \
    --password "4esZXdr5" 

   


    fg 1